package es.iesclaradelrey.da2d1e.shopeahjdr.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopEahJdrWebApplicationTests {

    @Test
    void contextLoads() {
    }

}

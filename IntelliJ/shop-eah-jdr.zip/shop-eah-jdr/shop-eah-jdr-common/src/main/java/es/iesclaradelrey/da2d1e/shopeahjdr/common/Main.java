package es.iesclaradelrey.da2d1e.shopeahjdr.common;


public class Main {
    public static void main(String[] args) {}
}
